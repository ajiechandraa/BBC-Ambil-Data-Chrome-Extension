chrome.runtime.onInstalled.addListener(() => {
    // Kode yang dijalankan saat ekstensi diinstal
    console.log("Ekstensi terinstal");
});

chrome.action.onClicked.addListener((tab) => {
    // Kode yang dijalankan saat ikon ekstensi diklik
    chrome.tabs.create({ url: "popup.html" }); // Ganti dengan URL yang sesuai
});
