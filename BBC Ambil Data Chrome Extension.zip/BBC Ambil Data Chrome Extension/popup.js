document.getElementById('fetchNews').addEventListener('click', async () => {
    const url = document.getElementById('newsLink').value;
    console.log('Fetching news from:', url); 
    const corsProxy = 'https://api.codetabs.com/v1/proxy?quest=';
    try {
        const response = await fetch(corsProxy + encodeURIComponent(url));
        console.log('Response status:', response.status); 
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.statusText);
        }
        const text = await response.text();
        console.log('Fetched text:', text); 
        const parser = new DOMParser();
        const doc = parser.parseFromString(text, 'text/html');

        const title = doc.querySelector('h1'); // Selector untuk judul
        const body = doc.querySelector('article'); // Selector untuk isi berita

        if (title && body) {
            document.getElementById('newsTitle').innerText = title.innerText;
            document.getElementById('newsBody').innerText = body.innerText;
            console.log('News title:', title.innerText); 
            console.log('News body:', body.innerText); 
        } else {
            console.error('Title or body not found in the fetched document.'); 
        }
    } catch (error) {
        console.error('Error fetching news:', error); 
        alert('Terjadi kesalahan saat mengambil berita. Silakan coba lagi.'); 
    }
});

document.getElementById('geturl').addEventListener('click', function() {
    document.getElementById('newsBody').innerText = "Sedang Mengambil Data.."; // Menambahkan teks
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
        document.getElementById('newsLink').value = tabs[0].url;
        // Panggil fungsi fetching data secara otomatis
        fetchData(tabs[0].url);
    });
});

async function fetchData(url) {
    console.log('Fetching data from:', url);
    const corsProxy = 'https://api.codetabs.com/v1/proxy?quest=';
    try {
        const response = await fetch(corsProxy + encodeURIComponent(url));
        console.log('Response status:', response.status);
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.statusText);
        }
        const text = await response.text();
        console.log('Fetched text:', text);
        const parser = new DOMParser();
        const doc = parser.parseFromString(text, 'text/html');

        const title = doc.querySelector('h1'); // Selector untuk judul
        const body = doc.querySelector('article'); // Selector untuk isi berita

        if (title && body) {
            document.getElementById('newsTitle').innerText = title.innerText;
            document.getElementById('newsBody').innerText = body.innerText; // Menampilkan isi berita
            console.log('News title:', title.innerText);
            console.log('News body:', body.innerText);
        } else {
            console.error('Title or body not found in the fetched document.');
        }
    } catch (error) {
        console.error('Error fetching news:', error);
        alert('Terjadi kesalahan saat mengambil berita. Silakan coba lagi.');
    }
    // Tidak ada penghapusan teks di sini
}
