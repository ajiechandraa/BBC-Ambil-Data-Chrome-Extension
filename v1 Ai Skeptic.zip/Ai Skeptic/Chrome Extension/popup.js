document.getElementById('fetchNews').addEventListener('click', async () => {
    // Menghapus event listener dari tombol fetchNews
    // ... kode yang ada sebelumnya ...
});

// Gabungkan aksi Get URL dan fetchNews dalam satu tombol
document.getElementById('getUrlButton').addEventListener('click', async () => {
    const url = await getCurrentTabUrl(); // Mendapatkan URL tab aktif
    document.getElementById('newsLink').value = url; // Memasukkan URL ke input

    // Lanjutkan dengan fetchNews
    document.getElementById('devilAdvocate').style.display = 'none'; // Menyembunyikan saat tombol ditekan
    document.getElementById('newsBody').style.display = 'block'; // Menampilkan saat mengambil data
    document.getElementById('newsBody').innerText = 'Reading the news...'; // Menampilkan teks saat mengambil data
    console.log('Fetching news from:', url); 
    const corsProxy = 'https://api.codetabs.com/v1/proxy?quest=';
    try {
        const response = await fetch(corsProxy + encodeURIComponent(url));
        console.log('Response status:', response.status); 
        if (!response.ok) {
            throw new Error('Network response was not ok: ' + response.statusText);
        }
        const text = await response.text();
        console.log('Fetched text:', text); 
        const parser = new DOMParser();
        const doc = parser.parseFromString(text, 'text/html');

        const title = doc.querySelector('h1'); // Selector untuk judul
        const body = doc.querySelector('article'); // Selector untuk isi berita

        if (title && body) {
            document.getElementById('aiSummary').style.display = 'block'; // Menampilkan saat mendapatkan ringkasan
            document.getElementById('devilAdvocate').style.display = 'block'; // Menampilkan setelah data diambil
            document.getElementById('newsTitle').innerText = title.innerText;
            document.getElementById('newsBody').innerText = body.innerText;
            console.log('News title:', title.innerText); 
            console.log('News body:', body.innerText); 
            getAISummary(body.innerText);
        } else {
            console.error('Title or body not found in the fetched document.'); 
        }
    } catch (error) {
        console.error('Error fetching news:', error); 
        alert('Error fetching news'); 
    }
});

async function getAISummary(newsContent) {
    document.getElementById('aiSummary').innerText = 'Criticizing the news...'; // Menampilkan teks saat mengkritik data
    try {
        const response = await fetch(`http://localhost:3000/chat?${encodeURIComponent(newsContent)}`); // Ganti dengan endpoint server Anda
        console.log('AI Summary response status:', response.status); // Menambahkan log status
        if (response.ok) {
            const summary = await response.text();
            document.getElementById('aiSummary').innerText = summary;
        } else {
            console.error('Error fetching AI summary:', response.statusText);
            alert('Error fetching AI');
        }
    } catch (error) {
        console.error('Error fetching AI summary:', error);
        alert('Error fetching AI');
    }
}

// Tambahkan fungsi untuk mendapatkan URL tab aktif
async function getCurrentTabUrl() {
    return new Promise((resolve) => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const activeTab = tabs[0];
            resolve(activeTab.url);
        });
    });
}