// Mendengarkan pesan dari background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "doSomething") {
        // Lakukan sesuatu di halaman
        alert("Ekstensi telah diaktifkan!");
        sendResponse({ status: "success" });
    }
});

// Contoh fungsi untuk mengirim pesan ke background script
function sendMessageToBackground() {
    chrome.runtime.sendMessage({ action: "doSomething" }, (response) => {
        console.log(response.status);
    });
}

// Menambahkan event listener pada elemen tertentu
document.addEventListener("click", (event) => {
    if (event.target.matches("#myButton")) { // Ganti dengan selector yang sesuai
        sendMessageToBackground();
    }
});
